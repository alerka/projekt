import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import App from './App.jsx'
import './index.css'
import RegPage from './pages/RegPage.jsx';
import HomePage from './pages/HomePage.jsx';
import LoginPage from './pages/LoginPage.jsx';
import ProgramsPage from './pages/ProgramsPage.jsx';
import AuthProvider from './context/AuthContext.jsx';
import AboutPage from './pages/AboutPage.jsx';
import Profile from './pages/Profile.jsx';
import TrainingPage from './pages/TrainingPage.jsx';
import ProgramPage from './pages/ProgramPage.jsx';
import UserProvider from './components/Protected.jsx';
import ProfileInfo from './pages/ProfileChange.jsx';

const router = createBrowserRouter([
  {
    path: '/',
    element: <HomePage />,
    errorElement: <div className='text-red-400'>404 nincs ilyen oldal</div>
  },
  {
    path: '/home',
    element: <HomePage/>,
  },
  {
    path: '/login',
    element: <LoginPage/>,
  },
  {
    path: '/register',
    element: <RegPage/>
  },
  {
    path: '/programs',
    element: <ProgramsPage/>
  },
  {
    path: '/profile',
    element: <UserProvider><Profile/></UserProvider>
  },
  {
    path: '/about',
    element: <AboutPage/>
  },
  {
    path: '/training',
    element: <TrainingPage/>
  },
  {
    path: '/program',
    element: <ProgramPage/>
  },
  {
    path: '/profileInfo',
    element: <UserProvider><ProfileInfo/></UserProvider>
  },
]);

ReactDOM.createRoot(document.getElementById('root')).render(
  <AuthProvider>
    <RouterProvider router={router}/>
  </AuthProvider>
)
