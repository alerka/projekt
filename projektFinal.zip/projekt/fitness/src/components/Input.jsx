import React from 'react';
import { useState } from 'react';

const Input = (props) => {
    const [error, setError] = useState(null);

    const stateHand = () => {
        props.click(props?.id);
    }

    let osztaly = "inputBorder border-2";
    return (
        <div className='input '>
        <p className="font-semibold p-1">{props?.label}</p>
            <div className={props.active === props?.id ? `${osztaly} border-sky-300` : osztaly}>
                <img src={props?.img} className='loginImg'></img>
                <span className='p-1'>|</span>
                <input maxLength={30} className="inputField" type={props?.type} onChange={props.change} placeholder={props?.placeholder} id={props?.id} onClick={stateHand}></input>
            </div>
            {error !== null &&
                <p className="font-semibold text-rose-600">{props?.errorMsg}</p>
            }
        </div>
  )
}

export default Input