import React, { useEffect, useState } from 'react'
import NavItem from './NavItem'
import Img from '../imgs/user.png'
import arrow from '../imgs/arrow.png'
import clsx from 'clsx'
import { FaArrowAltCircleUp } from "react-icons/fa";
import { FaArrowCircleDown } from "react-icons/fa";
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const NavBar = () => {
  const { user, setToken, setUser } = useAuth();
  //console.log(user);
  const [userName, setUsername] = useState("Bejelentkezés")
  const [loggedIn, setLogin] = useState(false);
  const [dropdown, setDropdown] = useState(false);
  const [smallbar, setSmallbar] = useState(false);
  const navigator = useNavigate();
  const logout = () => {
    //console.log("logout");
    setToken();
    setUser();
    setUsername("Bejelentkezés");
    setDropdown(false);
    localStorage.removeItem("token");
    setLogin(false);
    navigator('/login', { replace: true })
  }
  useEffect(() => {
    if (user) {
      //console.log("change")
      setLogin(true);
      setUsername(user.name);
    }
  }, [user]);

  const clickhandle = () => {
    setDropdown(!dropdown);
  }

  return (
    <nav className='bg-teal-600 shadow-md p-2 text-2xl max-sm:p-0 font-sans text-white'>
      <div className='flex items-center'>
        <div className='flex flex-1 items-center max-sm:hidden '>
          <div className='flex items-center justify-start gap-2'>
            <p className='w-fit font-semibold '>Fitness program</p>
          </div>
          <div className='w-full flex justify-center items-center gap-1'>
            <NavItem href="/home">Főoldal</NavItem>
            <NavItem href="/programs">Programok</NavItem>
            <NavItem href="/about">GYIK</NavItem>
          </div>
        </div>
        <div className='hidden max-sm:block w-full'>
          <NavItem className="bg-teal-600 border-teal-700 w-full p-1 border hover:bg-teal-700" href="/home">Főoldal</NavItem>
          {smallbar ?
            <>
              <NavItem className="bg-teal-600 border-teal-700 w-full p-1 border hover:bg-teal-700" href="/programs">Programok</NavItem>
              <NavItem className="bg-teal-600 border-teal-700 w-full p-1 border hover:bg-teal-700" href="/about">GYIK</NavItem>
              {loggedIn ?
                <>
                  <NavItem className="bg-teal-600 border-teal-700 w-full p-1 border hover:bg-teal-700" href="/profile" >Profilom</NavItem>
                  <NavItem className="bg-teal-600 border-teal-700 w-full p-1 border hover:bg-teal-700" href="/profileInfo" >Adatok</NavItem>
                  <NavItem className="bg-teal-600 border-teal-700 w-full p-1 border hover:bg-red-500" click={logout}>Kijelentkezés</NavItem>
                </>
                :
                <NavItem className="bg-teal-600 border-teal-700 w-full p-1 border hover:bg-teal-700" href="/login">Bejelentkezés</NavItem>
              }
              <div className="bg-teal-500 border-teal-700 w-full p-1 border hover:bg-teal-700 text-center" onClick={() => setSmallbar(!smallbar)}>
                <div className='border-b-4 border-transparent max-sm:hover:border-white sm:hover:border-teal-700 flex justify-center'><FaArrowAltCircleUp />
                </div>
              </div>
            </>
            :
            <div className="bg-teal-500 border-teal-700 w-full p-1 border hover:bg-teal-700 text-center" onClick={() => setSmallbar(!smallbar)}>
              <div className='border-b-4 border-transparent max-sm:hover:border-white sm:hover:border-teal-700 flex justify-center'><FaArrowCircleDown /></div>
            </div>
          }
        </div>

        <div className='items-center max-sm:hidden'>
          <div className='flex border-l border-teal-800 p-1 rounded-sm max-md:w-full hover:cursor-pointer' onClick={loggedIn ? clickhandle : () => navigator('/login', { replace: true })}>
            <img src={Img} className='w-8' />
            <p id="name" className='max-md:hidden hover:text-teal-200'>{userName}</p>
            {loggedIn &&
              <img src={arrow} className={clsx('font-extrabold w-8 h-8 ml-1 max-md:hidden', dropdown ? "rotate-90" : "rotate-180")}></img>
            }
          </div>
          <div className={clsx('flex absolute top-0 right-0 mt-14 bg-teal-500 border border-teal-700 w-52 pt-0 rounded-sm mr-1', dropdown ? "block" : "hidden disabled:")}>
            <ul className='w-full'>
              {loggedIn ?
                <>
                  <li><p className='w-full p-1 border-b border-teal-600 hover:bg-teal-600 cursor-pointer' onClick={() => navigator('/profile', { replace: true })}>Profilom</p></li>
                  <li><p className='w-full p-1 border-b border-teal-600 hover:bg-teal-600 cursor-pointer' onClick={() => navigator('/profileInfo', { replace: true })}>Adatok</p></li>
                  <li><p className='w-full p-1  hover:bg-red-500 cursor-pointer' onClick={logout}>Kijelentkezés</p></li>
                </>
                :
                <li><p className='w-full border-b border-teal-700 hover:bg-teal-500 p-1 cursor-pointer' onClick={() => navigator('/login', { replace: true })}>Bejelentkezés</p></li>
              }
            </ul>
          </div>
        </div>
      </div>
    </nav>
  )
}

export default NavBar