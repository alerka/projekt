import clsx from 'clsx';
import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom';

const ExerciseCard = ({ item, cancel, sendError, sender, remove }) => {
    const navigator = useNavigate();
    const [error, setError] = useState();
    const [reps, setReps] = useState(1);
    const [series, setSeries] = useState(1);
    const [done, setDone] = useState(false);
    const bodyWeight = item.bodyWeight;
    const [data, setData] = useState({
        exerciseId: item.id,
        quanity: 1,
        weight: 0,
        series: 1,
    });
    const handleRemoveClick = () => {
        setReps(0);
        setSeries(0);
        setError(undefined);
        cancel();
    }

    const checkData = async() => {
        if (sender) {
            if (data.quanity <= 0) {
                setError("Adja meg az ismétléseket!")
                sendError();
                return;
            }
            if (data.weight <= 0 && !bodyWeight) {
                setError("Válasszon súlyt!")
                sendError();
                return;
            }
            const response = await fetch("http://localhost:8000/user/setDay", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + localStorage.getItem("token")
                },
                body: JSON.stringify(data)
            });
            const valasz = await response.json();
            if(valasz.error) {
                setError(valasz.error);
                sendError();
            }
            remove();
        }
    }

    useEffect(() => {
        checkData();
    }, [sender])

    const handleChange = (item) => {
        setData({ ...data, [item.name]: Number(item.value) })
    }

    const [tomb, setTomb] = useState([]);
    const szamok = () => {
        const tombocske = [0]
        for (let i = 1; i <= 20; i++) {
            tombocske.push((i * 2.5))
        }
        for (let i = 6; i <= 15; i++) {
            tombocske.push((i * 10))
        }
        setTomb(tombocske)
    }
    useMemo(() => {
        szamok();
    }, [])
    const changeValue = (jel) => {
        if (jel == '-') {
            if (reps - 1 >= 1) {
                setReps(reps - 1);
                setData({ ...data, quanity: reps - 1 })
            }
        }
        if (jel == '+') {
            if (reps + 1 <= 50) {
                setReps(reps + 1);
                setData({ ...data, quanity: reps + 1 })
            }
        }
    }
    const changeSets = (jel) => {
        if (jel == '-') {
            if (series - 1 >= 1) {
                setSeries(series - 1);
                setData({ ...data, series: series - 1 })
            }
        }
        if (jel == '+') {
            if (series + 1 <= 6) {
                setSeries(series + 1);
                setData({ ...data, series: series + 1 })
            }
        }
    }
    return (
        <div>
            {error && <p className='text-red-500 p-1 font-semibold text-center'>{error}</p>}
            <div className={clsx('bg-gray-100 rounded-md m-2', error ? 'border-red-500 border-2' : 'border-gray-500 border')}>
                <div className='bg-teal-800 flex items-center divide-x border-teal-500 divide-teal-500 text-teal-400 rounded-[4px] rounded-b-none'>
                    <div className=' cursor-pointer w-5 ' onClick={() => changeSets('-')}>
                        <p className='text-center  font-semibold'>-</p>
                    </div>
                    <div className="w-10 text-center">{series}</div>
                    <div className='cursor-pointer w-5' onClick={() => changeSets('+')}>
                        <p className='text-center font-semibold'>+</p>
                    </div>
                </div>
                <div className='border rounded-md border-gray-500 p-2 gap-4 flex flex-row items-center text-black m-1'>
                    <div className=''>
                        <div className='bg-red-500 w-8 h-8 cursor-pointer text-center p-1 rounded font-semibold' onClick={handleRemoveClick}>x</div>
                    </div>
                    <h1 className='text-center font-semibold w-1/6'>{item?.name}</h1>
                    <div>
                        <p className='text-sm font-semibold text-center'>Ismétlések</p>
                        <div className='bg-teal-800 flex items-center border divide-x border-teal-500 divide-teal-500 text-teal-400 rounded-sm'>
                            <div className=' cursor-pointer w-5 ' onClick={() => changeValue('-')}>
                                <p className='text-center  font-semibold'>-</p>
                            </div>
                            <div className="w-10 text-center">{reps}</div>
                            <div className='cursor-pointer w-5' onClick={() => changeValue('+')}>
                                <p className='text-center font-semibold'>+</p>
                            </div>
                        </div>
                    </div>
                    <div className='text-black'>
                        <p className='text-sm font-semibold text-center'>Súly (KG)</p>
                        {!bodyWeight ?
                            <div>
                                {tomb?.length > 0 &&
                                    <select name='weight' className='p-1 rounded-sm bg-teal-800 text-teal-500 border border-teal-500' defaultValue={0} onChange={e => handleChange(e.target)}>
                                        {tomb.map((a) => (
                                            <option key={a} value={a}>{a}</option>
                                        ))}
                                    </select>}
                            </div>
                            :
                            <select className='p-1 rounded-sm bg-teal-800 text-teal-500 border border-teal-500' disabled={true}>
                                <option value={0}>ST</option>
                            </select>
                        }
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ExerciseCard