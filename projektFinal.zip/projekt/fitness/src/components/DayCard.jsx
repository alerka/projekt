import clsx from 'clsx';
import React from 'react'

const DayCard = ({ selectedKey, isActive, text, clickEvent, keyId, current, click }) => {

    const handleClickEvent = () => {
        if(current) {
            return;
        }
        if (isActive) {
            clickEvent(keyId);
            click(keyId);
        }
    }

    return (
        <>
            <div className={clsx(`
        container  
        border 
        w-20 
        h-20 
        rounded
        flex 
        items-center 
        justify-center 
        m-1
        `, current 
        ? 
            'bg-green-500 border-green-600 '
        :   
        selectedKey === keyId 
        ?
            "border-green-500 bg-green-400 cursor-pointer"
        :
        isActive & selectedKey !== keyId 
        ? 
            "bg-gray-500 border-gray-700 hover:bg-gray-400 cursor-pointer"
        : 
            "bg-gray-400 border-gray-600")} 
        onClick={handleClickEvent}>
                <p className='text-gray-200 text-center'>{text}</p>
            </div>
        </>
    )
}

export default DayCard