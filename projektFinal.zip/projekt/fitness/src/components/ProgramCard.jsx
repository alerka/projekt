import React from 'react'
import { useAuth } from '../context/AuthContext'
import { useNavigate } from 'react-router-dom';
import clsx from 'clsx'

const ProgramCard = ({ image, title, desc, id}) => {
  const { user } = useAuth();
  const navigator = useNavigate();
  const handleSelect = () => {
    navigator(`/program?id=${id}`, { replace: true })
  }
  return (
    <>
      <div className='bg-cyan-500 border border-blue-600 text-white rounded-sm h-full mt-2 justify-between flex flex-col'>
        <div>
          <img src={image} className='object-cover w-full h-48'></img>
          <h1 className='text-2xl font-bold text-center mt-2'>{title}</h1>
          <p className='p-3 '>{desc}</p>
        </div>
        <div className='flex justify-center items-center'>
            <div className={clsx('bg-green-500 border border-green-600 hover:bg-green-600 w-1/3 text-white text-center p-1 my-3', user?.progrmaId ? 'cursor-not-allowed' : 'cursor-pointer')} 
            onClick={user ? handleSelect : () => navigator('/login', { replace: true })}>
              Kiválasztás
            </div>
        </div>
      </div>
    </>
  )
}

export default ProgramCard