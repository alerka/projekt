import React from 'react'
import clsx from 'clsx'
import { Navigate, useNavigate } from 'react-router-dom'

const NavItem = ({ className, href, children, click }) => {
  const navigator = useNavigate();
  const handleClick = () => {
    if(href) {
      navigator(href, { replace: true });
    }
  }
  return (
    <div className={clsx(className, "w-fit hover:cursor-pointer")} onClick={click ? click : handleClick}>
      <p className='p-1 border-b-4 border-transparent max-sm:hover:border-white sm:hover:border-teal-700'>{children}</p>
    </div>
  )
}

export default NavItem