import React from 'react'
import LoginPage from '../pages/LoginPage.jsx';
import { useAuth } from '../context/AuthContext.jsx';

const UserProvider = ({children}) => {
    const { user } = useAuth()
    if(!user) {
        return <LoginPage/>
    }
    return (
        <>{children}</>
    )
}

export default UserProvider