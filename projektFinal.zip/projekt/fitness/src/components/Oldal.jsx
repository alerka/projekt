import { useState } from 'react'
import ProgressBar from './components/ProgressBar'
import DaysGroup from './components/DaysGroup';

function Oldal() {
  const [progress, setProgress] = useState(1.12);

  let napok = [];
  for(let i = 0; i < 90; i++) {
    napok.push(i+1);
  }

  const addProgress = () => {
    setProgress(progress+1.12);
  }

  return (
    <>
      <ProgressBar progress={progress}/>
      <DaysGroup/>
    </>
  )
}

export default Oldal
