import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

const ProgressBar = ({ progress, day, click }) => {
  const [szazalek, setSzazalek] = useState(progress);
  return (
    <>
      <div className='container m-2 grid grid-cols-3 w-4/5 '>
        <div className='col-span-3 text-center text-xl'>
          Előre haladás:
        </div>
        <p className='text-left'>0</p>
        <p className='text-center'>45</p>
        <p className='text-right'>90</p>
        <div className='container bg-slate-400 p-1 rounded-sm col-span-3'>
          <div className='bg-gradient-to-r from-green-400 to-emerald-400 rounded-sm border-emerald-500 border' style={{ width: `${szazalek}%` }}>
            <p className='text-nowrap text-slate-600 font-bold text-center'>{day}. Nap</p>
          </div>
        </div>
        <div className='container col-span-3 bg-green-400 mt-2 rounded hover:bg-green-500'>
          <button className='w-full h-full p-2 border-2 border-green-500 rounded text-white hover:border-green-600' onClick={click}>Folytatás</button>
        </div>
      </div>
    </>
  )
}

export default ProgressBar