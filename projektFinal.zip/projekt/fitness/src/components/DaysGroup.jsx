import React, { useState } from 'react'
import DayCard from './DayCard'

const DaysGroup = ({user, setDay}) => {
  const [selectedIndex, setSelected] = useState(-1);

  let napok = [];
  for (let i = 0; i < 90; i++) {
    napok.push(i + 1);
  }

  const handleSelected = (index) => {
    setSelected(index);
  }

  const handleCurrent = async (item) => {
    //console.log("fasds", item);
    const data = await fetch(`http://localhost:8000/user/getDays?day=${item}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + localStorage.getItem("token")
      }
    });
    const adat = await data.json();
    setDay(adat);
  }

  return (
    <div className='container flex flex-row flex-wrap items-center justify-center p-1'>
      {napok.map((item) => (
        item == user?.day ? <DayCard text={item} key={item} current={true} click={() => handleCurrent(item)} />
          :
          item < user?.day ? <DayCard text={item} isActive={true} selectedKey={selectedIndex} clickEvent={handleSelected} click={() => handleCurrent(item)} key={item} keyId={item} current={false} />
            :

            <DayCard text={item} isActive={false} key={item} selectedKey={selectedIndex} keyId={item} />
      ))}
    </div>
  )
}

export default DaysGroup