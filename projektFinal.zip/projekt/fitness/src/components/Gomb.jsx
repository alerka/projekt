import React from 'react'

const Gomb = (prop) => {
  return (
    <div className='text-center bg-green-500 p-2 rounded-md w-96 m-2 hover:bg-green-600 cursor-pointer' onClick={prop.click} >
      <p>{prop.title}</p>
    </div>
  )
}

export default Gomb