import { createContext, useContext, useEffect, useMemo, useState } from "react";

const AuthContext = createContext();
const AuthProvider = ({ children }) => {
    const [token, setToken] = useState(localStorage.getItem("token"));
    const [programs, setPrograms] = useState();
    const [user, setUser] = useState();
    const napok = ["Vasárnap", "Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat"];
    const getUser = async () => {
        if (token) {
            const response = await fetch("http://localhost:8000/user/getUser", {
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + token
                },
            })
            const data = await response.json();
            if(data.message) {
                setUser(undefined);
                return;
            }
            setUser(data);
        }
    }
    const getPrograms = async () => {
        const data = await fetch("http://localhost:8000/api/programs");
        const response = await data.json();
        //console.log(response)
        setPrograms(response);
    }
    useMemo(() => {
        getPrograms();
    },[])
    useEffect(() => {
        getUser();
    }, [token])
    return <>
    <AuthContext.Provider value={{programs, user, setToken, setUser, napok}} >
        {children}
    </AuthContext.Provider>
    </>
}
export const useAuth = () => {
    return useContext(AuthContext);
}

export default AuthProvider;