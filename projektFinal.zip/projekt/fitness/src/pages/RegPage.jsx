import React, { useEffect } from 'react'
import NavBar from '../components/NavBar'
import pwImg from '../imgs/pw.png'
import emailImg from '../imgs/email.png'
import userImg from '../imgs/user.png'
import phoneImg from '../imgs/phone.png'
import Input from '../components/Input'
import { useState } from 'react'
import Gomb from '../components/Gomb'
import { useAuth } from '../context/AuthContext'
import { useNavigate } from 'react-router-dom'

const RegPage = () => {
  const { setToken, user } = useAuth();

  useEffect(() => {
    if (user) {
      navigate("/home", { replace: true });
    }
  }, [user])
  const [inputState, setState] = useState("");
  const [data, setData] = useState({
    email: "",
    name: "",
    password: "",
    passwordAgain: "",
    phone: ""
  })
  const navigate = useNavigate();
  const [error, setError] = useState("");
  const stateHandler = (id) => {
    setState(id);
  }

  const handleChange = (e) => {
    setData({ ...data, [e.target.id]: e.target.value })
  }

  const handleRegister = async () => {

    if (data.name.length < 4) {
      setError("A felhasználónév túl rövid!");
      return;
    }
    if (!data.email.includes("@")) {
      setError("Helytelen email!");
      return;
    }
    if (!data.phone && data.phone.length != 11) {
      setError("Add meg a telefonszámod!");
      return;
    }
    if (data.password.length < 6) {
      setError("Túl rövid a jelszavad!");
      return;
    }
    if (data.passwordAgain != data.password) {
      setError("A két jelszó nem egyezik!");
      return;
    }
    setError("");

    const response = await fetch("http://localhost:8000/user/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    });
    const adat = await response.json();
    if (adat.message) {
      setError(adat.message)
    } else {
      localStorage.setItem('token', adat.token);
      setToken(adat.token);
      navigate("/home", { replace: true })
    }
  }

  return (
    <div>
      <NavBar />
      <div className='inputs flex justify-center items-center'>
        <ul className='w-96'>
          <li>
            <h1 className='text-4xl text-center p-3'>Regisztráció</h1>
          </li>
          <li>
            <p id="error" className='text-xl text-red-600'>{error}</p>
            <Input label='Felhasználónév' id="name" placeholder="felhasználó" img={userImg} type='text' click={stateHandler} change={handleChange} active={inputState}></Input>
          </li>
          <li>
            <Input label='Email' id="email" placeholder="példa@gmail.com" img={emailImg} type='email' click={stateHandler} change={handleChange} active={inputState}></Input>
          </li>
          <li>
            <Input label='Telefonszám' id="phone" placeholder="+36 30 123 4567" img={phoneImg} type='string' click={stateHandler} change={handleChange} active={inputState}></Input>
          </li>
          <li>
            <Input label='Jelszó' id="password" placeholder="•••••••••" img={pwImg} type='password' click={stateHandler} change={handleChange} active={inputState}></Input>
          </li>
          <li>
            <Input label='Jelszó mégegyszer' id="passwordAgain" placeholder="•••••••••" img={pwImg} type='password' click={stateHandler} change={handleChange} active={inputState}></Input>
          </li>
          <li>
            <p className='p-2'>Már van fiókod? Itt tudsz <a href='/login' className='text-amber-600'>Bejelentkezni</a>!</p>
          </li>
          <li className='flex justify-center'>
            <Gomb title="Regisztráció" click={handleRegister}></Gomb>
          </li>
        </ul>
      </div>
    </div>
  )
}

export default RegPage