import React from 'react'
import NavBar from '../components/NavBar'

const AboutPage = () => {
    return (
        <div className='bg-zinc-100 font-sans'>
            <NavBar/>
            <div className='w-6/12 h-full m-auto'>
                <h1 className='text-2xl font-bold text-center p-8 '>Gyakran ismételt kérdések</h1>
                <div className='text-left'>
                    <h1 className='text-xl font-semibold pb-3'>Mit válasszak?</h1>
                    <p className='pb-16'>
                        Attól függ, hogy mi a célod. A programok keretében 3 fajta edzésre is van
                        lehetőség mind a három program ki van hegyezve a megfelelő edzéstípusokra. A
                        programok fülnél a leírások alapján ki tudod választani 
                        neked tetsző és megfelelő programot.
                    </p>
                    <h1 className='text-xl font-semibold pb-3'>Mire számítsak?</h1>
                    <p className='pb-16'>
                        Az edzésbe idő beleszokni, az elején gyakran lehet izomláz ami természetes és egy jó jel arra, hogy azt az 
                        izomcsoportot kellően megmozgattuk és megkapta azt az ingert ami az izomnövekedést, fejlődést váltja ki. A 
                        láb edzések lehetnek különlegesen kényelmetlenek, mivel a láb az az izomcsoport amit rendszeresen használunk,
                        ezért nehezebben tud regenerálódni.
                    </p>
                    <h1 className='text-xl font-semibold pb-3'>Mikor látható fejlődés?</h1>
                    <p className='pb-16'>
                       A fejlődés mindenkinél másképp jelentkezik. Átlagosan a leggyorsabb fejlődés a túlsúlyos
                       embereknél jelentkezik a mérlegen. Genetikától függően akár 1 hónap után drasztikus átváltozások történhetnek, de
                       90 nap már a legtöbb embernél látványos átváltozást tud okozni. A lényeg, hogy ha nem látszik a fejlődés ne adjuk fel
                       ez egy olyan folyamat ami mellett kitartóan kell csinálni.
                    </p>
                    <h1 className='text-xl font-semibold pb-3'>Hogyan motiválhatom magam?</h1>
                    <p className='pb-16'>
                       Edzésre rengeteg motivációs videó található az interneten legtöbbször mások fizikumából
                       vagy eredményéből szerezhetünk motivációt, de programtól függően sok olyan dolog van ami motivál,
                       például <b>saját testsúlyos</b> edzésnél valamilyen gyakorlatot elsajátítani, <b>testépítésnél</b> látni 
                       ahogy az izom épül és látható lesz a fejlődés, <b>erőemelésnél</b> egyéni súly rekordot
                       dönteni. Ezek mellett a mindennapi edzésekre és edzés közbeni motivációra zenék segíthetnek,
                       esetleg stimuláló szerek, például energiatial, edzés előtti.
                    </p>
                    <h1 className='text-xl font-semibold pb-3'>Kinek ajánlott?</h1>
                    <p className='pb-16'>
                       Mindenkinek aki szeretné a mozgást az életébe beépíteni és a legjobb formába
                       kerülni fizikailag. A mentális egészségben is segít, mivel a testedben magabiztosabban
                       érzed magad és edzés közben megtanulhatod kitolni a határokat fizikailag.
                    </p>
                </div>
            </div>
        </div>
    )
}

export default AboutPage