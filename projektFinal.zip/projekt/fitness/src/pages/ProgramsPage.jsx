import React, { useEffect, useMemo, useState } from 'react'
import ProgramCard from '../components/ProgramCard'
import NavBar from '../components/NavBar'
import { useAuth } from '../context/AuthContext'
import clsx from 'clsx'

const ProgramsPage = () => {
  const { user, programs, napok } = useAuth();
  const [userProgram, setUserProgram] = useState();
  const [programPlan, setPlan] = useState();
  const [currentDay, setDay] = useState(1);
  const getPlan = async (id) => {
    const data = await fetch(`http://localhost:8000/api/programPlan?programId=${id}}`);
    const adat = await data.json();
    setPlan(adat);
  }
  useEffect(() => {
    if (user && programs) {
      for (let i = 0; i < programs.length; i++) {
        if (programs[i].id == user.programId) {
          getPlan(programs[i].id);
          setUserProgram(programs[i]);
        }
      }
    }
  }, [user])

  useMemo(() => {
    const date = new Date();
    const day = date.getDay();
    setDay(day);
  }, []);
  const handleClick = () => {
    location.href = 'http://localhost:5173/training'
  }
  return (
    <>
      <NavBar />
      <div>
        {user &&
          <div className='bg-cyan-500 text-white border border-blue-300 rounded-sm m-5'>
            <div className={clsx(user?.programId && 'grid lg:grid-cols-9 lg:divide-x-2 max-lg:divide-y-2')}>
              <div className='lg:col-span-2 p-2 max-lg:row-span-2 bg-cyan-500'>
                <h1 className='text-lg font-semibold  max-lg:text-center bg-cyn'>{user?.programId ? 'Aktív programod:' : 'Nincs aktív programod!'}</h1>
                {user?.programId &&
                  <h1 className='text-2xl font-semibold text-teal-600 text-wrap lg:flex text-center'>{userProgram?.title}</h1>
                }
              </div>
              <div className='lg:col-span-7 grid lg:grid-cols-7 max-md lg:divide-x-2 max-sm:grid-rows-7 max-lg:grid-rows-7 max-lg:divide-y-2'>
                {(userProgram && programPlan) && Object.keys(programPlan).map((key, index) => (
                  <div key={index} className={clsx('text-center p-2 bg-cyan-500', index > 5 && currentDay === 0 ? 'bg-green-500' : index + 1 === currentDay && 'bg-green-500')}>
                    {index > 5 ?
                      <>
                        <h1 className='text-lg font-semibold'>{napok[0]}</h1>
                        <h1>{programPlan['snday']}</h1>
                        {currentDay === 0 &&
                          <div className='bg-green-600 rounded border border-emerald-600 hover:cursor-pointer hover:bg-emerald-600' onClick={handleClick}>
                            Kezdés
                          </div>
                        }
                      </>
                      :
                      <>
                        <h1 className='text-lg font-semibold'>{napok[index + 1]}</h1>
                        <h1>{programPlan[key]}</h1>
                        {currentDay === index + 1 &&
                          <div className='bg-green-600 rounded border border-emerald-600 hover:cursor-pointer hover:bg-emerald-600' onClick={handleClick}>
                            Kezdés
                          </div>
                        }
                      </>
                    }

                  </div>
                ))}
              </div>
            </div>
          </div>
        }
        {programs?.length > 0 && <h1 className='col-span-3 bg-teal-600 p-2 text-3xl text-white font-semibold text-center'>ELÉRHETŐ PROGRAMOK</h1>}
        <div className='grid grid-cols-3 max-lg:grid-cols-2 max-md:grid-cols-1 m-16 max-sm:m-4 mt-2 gap-16 max-sm:gap-4'>
          {programs?.length > 0 ? programs?.map((item) => (
            <ProgramCard image={item.image} key={item.id} id={item.id} title={item.title} desc={item.description} />
          ))
            :
            <p className='text-2xl text-center col-span-3'>Jelenleg nincsenek elérhető programok!</p>
          }
        </div>
      </div>
    </>
  )
}

export default ProgramsPage