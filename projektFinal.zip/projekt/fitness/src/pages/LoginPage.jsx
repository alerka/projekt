import React, { useEffect, useState } from 'react'
import NavBar from '../components/NavBar'
import Input from '../components/Input'
import pwImg from '../imgs/pw.png'
import emailImg from '../imgs/email.png'
import Gomb from '../components/Gomb'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const LoginPage = () => {
    const { setToken } = useAuth();
    const navigate = useNavigate();
    const [inputState, setState] = useState("");
    const [error, setError] = useState("");
    const [data, setData] = useState({
        email: "",
        password: ""
    });

    const { user } = useAuth();

    useEffect(() => {
        if (user) {
            navigate("/home", { replace: true });
        }
    }, [user])

    const stateHandler = (id) => {
        setState(id);
    }

    const handleChange = (e) => {
        setData({ ...data, [e.target.id]: e.target.value })
    }

    const handleLogin = async () => {
        stateHandler(-1);

        const { email, password } = data;
        if (!email) {
            setError("Add meg a felhasználó neved!");
            return;
        }
        if (!password) {
            setError("Add meg a jelszavad!");
            return;
        }
        const response = await fetch("http://localhost:8000/user/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });
        const adat = await response.json();
        if (adat.message) {
            setError(adat.message);
        } else {
            localStorage.setItem('token', adat.token);
            setToken(adat.token);
            navigate("/home", { replace: true })
        }
    }

    return (
        <>
            <NavBar />
            <div className='inputs flex justify-center items-center'>
                <ul className='w-96'>
                    <li>
                        <h1 className='text-4xl text-center p-3'>Bejelentkezés</h1>
                    </li>
                    <li>
                        <p className='text-xl text-red-600 text-center'>{error}</p>
                        <Input label='Email' id="email" placeholder="példa@gmail.com" img={emailImg} type='email' click={stateHandler} change={handleChange} active={inputState}></Input>
                    </li>
                    <li>
                        <Input label='Jelszó' id="password" placeholder="•••••••••" img={pwImg} type='password' click={stateHandler} change={handleChange} active={inputState}></Input>
                    </li>
                    <li>
                        <p className='p-2'>Még nincs fiókod? Itt tudsz <a href='/register' className='text-amber-600'>Regisztrálni</a>!</p>
                    </li>
                    <li>
                        <Gomb title="Bejelentkezés" click={handleLogin}></Gomb>
                    </li>
                </ul>
            </div>
        </>
    )
}

export default LoginPage