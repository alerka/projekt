import React, { useMemo } from 'react'
import NavBar from '../components/NavBar';
import bg1 from '../imgs/caliGround.jpg';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const HomePage = () => {
  const { user } = useAuth()
  const navigator = useNavigate();
  const handleClick = () => {
    if(!user) {
      navigator("/register", { replace: true })
    }
  }
  return (
    <>
      <NavBar />
      <div className='w-full h-screen '>
        <img src={bg1} className=' object-cover max-h-96 w-full'></img>
        <h1 className='text-3xl font-bold p-4 text-white bg-teal-800 text-center border-t-2 border-b-2 border-white'>A MOZGÁS VILÁGA</h1>
        <div className='m-auto text-center bg-zinc-100 flex items-center pb-12'>
          <div className='grid grid-cols-2 w-full'>
            <div className='p-3 flex justify-end'>
              <div className='w-2/5 max-md:w-1/2 max-sm:w-full'>
                <h3 className='text-lg font-semibold text-right'>Mi ez az <span className='text-teal-500'>alkalmazás</span></h3>
                <p className='pl text-right'>Nem rég az edzésre kezdtem köszpontosítani, persze azelőtt is érdekelt, de utána belevetettem magam a mély vízbe és elkészítettem eme csodás alkalmazást amivel képesek mások is elmerülni az edzés világában.</p>
              </div>
            </div>
            <div className='p-3 flex justify-start'>
              <div className='w-2/5 max-md:w-1/2 max-sm:w-full text-left'>
                <h3 className='text-lg font-semibold'>Személyes <span className='text-teal-500'>tapasztalatok</span></h3>
                <p className='pl'>Az edzésterveket és gyakorlatokat több hét tesztelés és személyes tapasztalat alapján építettük ki. Ez nem azt jelenti, hogy mindneki számára a legmegfelelőbb, de a nagy átlagnak tökéletes!</p>
              </div>
            </div>
            <div className='p-3 flex justify-end'>
              <div className='w-2/5 max-md:w-1/2 max-sm:w-full'>
                <h3 className='text-lg font-semibold text-right'><span className='text-teal-500'>Olcsó</span> és <span className='text-teal-500'>egyszerű</span> használat</h3>
                <p className='pl text-right'>Az alkalmazás jelenleg ingyenesen használható egy egyszerű regisztráció után a <span className='text-teal-500 font-bold'>PROGRAMOK</span> fülnél megtekinthetjük az elérhető edzésterveket és kedvünk szerint kiválaszthatjuk azt.</p>
              </div>
            </div>
            <div className='p-3 flex justify-start'>
              <div className='w-2/5 text-left max-md:w-1/2 max-sm:w-full'>
                <h3 className='text-lg font-semibold'>További <span className='text-teal-500'>használat</span></h3>
                <p className='pl'>Amennyiben már a kedvező programot kiválasztottuk minden napra jutnak feladatok 90 napra előreláthatólag. A profil fülnél megtudjuk tekinteni a végigcsinált napokat. Található ott egy <span className='text-teal-500 font-semibold'>Folyamatjelző sáv</span> ahol a haladásunk van ábárzolva.</p>
              </div>
            </div>
          </div>
        </div>
        <div className='text-white bg-teal-800 text-center border-t-2 border-b-2 border-white  p-4 items-center justify-center'>
          <h1 className='text-3xl font-bold text-center'>CSATLAKOZZ!</h1>
          <div className='bg-teal-600 text-2xl font-bold p-2 text-center m-auto w-fit rounded border border-teal-500 hover:bg-teal-800 hover:cursor-pointer hover:border-teal-800' onClick={handleClick}>REGISZTRÁCIÓ</div>
        </div>
        <div className=''>
          <div className='grid grid-cols-3 max-md:grid-cols-1 p-12'>
            <div className='flex justify-center'>
              <div>
                <div className='w-36 h-36 inline-flex items-center justify-center rounded-full m-5 bg-teal-600 flex-row'>
                  <p className='text-white font-semibold text-2xl'>1.</p>
                </div>
                <p className='text-2xl text-center text-teal-500 font-bold'>REGISZTRÁLÁS</p>
                <p className='text-lg text-center text-teal-400 font-semibold'>Regisztrálj egy fiókot!</p>
              </div>
            </div>
            <div className='flex justify-center'>
              <div>
                <div className='w-36 h-36 inline-flex items-center justify-center rounded-full m-5 bg-teal-600'>
                  <p className='text-white font-semibold text-xl'>2.</p>
                </div>
                <p className='text-2xl text-center text-teal-500 font-bold'>KIVÁLASZTÁS</p>
                <p className='text-lg text-center text-teal-400 font-semibold'>Válassz egy programot</p>
              </div>
            </div>
            <div className='flex justify-center'>
              <div>
                <div className='w-36 h-36 inline-flex items-center justify-center rounded-full m-5 bg-teal-600'>
                  <p className='text-white font-semibold text-xl'>3.</p>
                </div>
                <div>
                  <p className='text-2xl text-center text-teal-500 font-bold'>EDZÉS</p>
                  <p className='text-lg text-center text-teal-400 font-semibold'>Kezdd el az edzést</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='bg-teal-800 text-teal-800 w-full'>
          a
        </div>
      </div>
    </>
  )
}

export default HomePage