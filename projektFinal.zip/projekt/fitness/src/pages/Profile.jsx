import React, { useEffect, useMemo, useState } from 'react'
import NavBar from '../components/NavBar'
import DaysGroup from '../components/DaysGroup'
import ProgressBar from '../components/ProgressBar'
import { useAuth } from '../context/AuthContext'
import clsx from 'clsx'

const Profile = () => {
    const { user, setUser } = useAuth();
    const [progress, setProgress] = useState(user?.day * 1.11);
    const [currentDay, setCurrentDay] = useState([]);
    const [exercises, setExercise] = useState([]);
    const [modal, setModal] = useState(false);

    const handleClick = () => {
        location.href = 'http://localhost:5173/training'
    }

    const setupExercise = (item) => {
        if (item) {
            let ujAdat = {};
            let exercise = {};
            exercises.map((ex) => {
                if(ex.id == item.exerciseId) {
                    exercise = ex;
                }
            })
            
            if(!exercise) {
                return;
            }

            Object.keys(item).map((i) => {
                if (i != "id" && i != "exerciseId" && i != "userId" ) {
                    ujAdat[i] = item[i];
                }
            })
            Object.keys(exercise).map((i) => {
                ujAdat[i] = exercise[i];
            })

            return ujAdat;
        }
    }

    const handleDayChange = (item) => {
        setCurrentDay(item.map((itm) => {
            return setupExercise(itm);
        }))
        setModal(true);
    }

    const handleClose = () => {
        setModal(false)
        setCurrentDay([])
    }

    useMemo(async() => {
        const data = await fetch("http://localhost:8000/api/exercises")
        setExercise(await data.json());
    }, [])

    return (
        <>
            <NavBar />
            <div className='flex flex-col items-center justify-center'>
                {
                    user && <ProgressBar progress={progress} day={user.day} click={handleClick} />
                }
                {user && <DaysGroup user={user} setDay={(item) => handleDayChange(item)} />}
            </div>
            {modal && <div className={clsx('bg-gray-700 bg-opacity-60 top-0 w-full h-full flex justify-center items-center fixed')}>
                <div className='bg-white p-2 rounded shadow-2xl border border-teal-400 shadow-teal-400 flex flex-col text-center'>
                    {currentDay.length > 0 && (
                        <>
                            <p className='font-semibold text-xl'>{currentDay[0]?.day || 0}. Nap</p>
                            <p className='font-medium w-full border-b border-gray-300'>{currentDay[0]?.type}</p>
                            <div className='m-2'>
                                {currentDay.length > 0 && currentDay?.map((item, index) => (
                                    <div key={index}>
                                        {item.weight > 0 ?
                                            <p className='font-semibold'>{item?.name} | {item?.series} x {item?.quanity} | {item?.weight} KG</p>
                                        :
                                            <p className='font-semibold'>{item?.name} | {item?.series} x {item?.quanity} | ST</p>
                                        } 
                                    </div>
                                        )
                                    )
                                }
                            </div>
                        </>
                    )}
                    <div className='bg-red-600 text-white rounded cursor-pointer' onClick={handleClose}>Bezárás</div>
                </div>
            </div>}
        </>
    )
}

export default Profile