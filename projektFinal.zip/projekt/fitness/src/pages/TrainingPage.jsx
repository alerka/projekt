import React, { useState, useEffect } from 'react'
import NavBar from '../components/NavBar'
import { useAuth } from '../context/AuthContext'
import ExerciseCard from '../components/ExerciseCard'
import clsx from 'clsx'

const TrainingPage = () => {
    const { user, programs } = useAuth();
    const [exercises, setExercises] = useState([]);
    const [open, setOpen] = useState(false);
    const [cards, setCards] = useState([]);
    const [send, setSend] = useState(false);
    const [day, setDay] = useState()
    const [status, setStatus] = useState(false);
    const ido = new Date().getDate();

    const changeEvent = () => {
        setSend(false);
    }

    const removeCard = (item) => {
        setCards(
            []
        );
        setStatus(true);
        if(cards.length <= 1) {
            for (let i = 0; i < programs.length; i++) {
                if (programs[i].id == user.programId) {
                    getPlan(programs[i].id);
                }
            }
        }
        setDay(day+1);
    }

    const elozoNap = async () => {
        const data = await fetch(`http://localhost:8000/user/getDays?day=${user?.day - 1}}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("token")
            }
        });
        const adat = await data.json();
        if(adat.length > 0) {
            const date = new Date(adat[0].date)
            setDay(date.getDate());
        }
    }

    const getPlan = async (id) => {
        const data = await fetch(`http://localhost:8000/api/programPlan?programId=${id}}`);
        const adat = await data.json();
        const date = new Date();
        let day = date.getDay();
        if(day == 0) {
            day = 7
        }
        getExercises(adat[Object.keys(adat)[day-1]]);
    }

    const getExercises = async (type) => {
        if(user.programId == 1) {
            const data = await fetch(`http://localhost:8000/api/exercises?type=${type}&program=bw`);
            const adat = await data.json();
            setExercises(adat);
        } else {
            const data = await fetch(`http://localhost:8000/api/exercises?type=${type}`);
            const adat = await data.json();
            setExercises(adat);
        }
    }

    useEffect(() => {
        if (user && programs) {
            elozoNap();
            for (let i = 0; i < programs.length; i++) {
                if (programs[i].id == user.programId) {
                    getPlan(programs[i].id);
                }
            }
        }
    }, [user])

    const addExercise = (name) => {
        setCards([
            ...cards,
            name
        ]);
        setExercises(
            exercises.filter(a =>
                a.id !== name.id
            )
        );
    }
    const removeExercise = (item) => {
        setCards(
            cards.filter(a =>
                a.id !== item.id
            )
        );
        setExercises([...exercises, item])
    }
    const handleOpen = () => {
        setOpen(!open);
    }

    useEffect(() => {
        if(send) {
            setOpen(false);
        }
    }, [send])

    return (
        <div>
            <NavBar />
            {user ?
                user?.programId ?
                    day !== ido ? 
                    <div className='m-4 rounded-md p-2 '>
                        <h1 className='text-center font-semibold text-2xl'>{user?.day}. Nap</h1>
                        {status ?
                        <div className='text-center p-2 text-2xl'>A mai napra készen vagy!</div>
                        :
                        <>
                        <div className='text-white gap-2'>
                            {cards?.length === 0 &&
                                <div className=' font-semibold p-2 text-center'>
                                    <p className='text-black'>Adj hozzá gyakorlatot!</p>
                                </div>
                            }
                            {cards.map((item, index) => (
                                <ExerciseCard item={item} key={"fi" + index} cancel={() => removeExercise(item)} sendError={changeEvent} sender={send} remove={() => removeCard(item)}/>
                            ))}
                        </div>

                        <div className='flex flex-col justify-center items-center'>
                            <div className={clsx('cursor-pointer border rounded-md border-gray-500 text-center w-1/3 m-1 mb-0', open && 'rounded-b-none')} onClick={handleOpen}>+</div>
                            <ul className={clsx('w-1/3 border border-gray-500 border-t-0 text-center bg-gray-400 divide-y divide-slate-500 rounded-b-md', (open && !send) ? 'inline-block' : 'hidden')}>
                                {exercises?.length > 0 ? exercises.map((item, index) => (
                                    <li key={"fa" + index} className='cursor-pointer p-1' onClick={() => addExercise(item)}>{item.name}</li>
                                ))
                                    :
                                    <li className='p-1'>Nincs több gyakorlat!</li>
                                }
                            </ul>
                            <div className='p-2 bg-green-500 rounded font-semibold text-white text-center m-4 border border-green-600 cursor-pointer hover:bg-green-600 w-1/3' onClick={() => { if (cards.length > 0) setSend(true) }}>Nap véglegesítése</div>
                        </div>
                        </>
                        }
                    </div>
                    :
                    <>
                        <h1 className='text-center font-semibold text-2xl'>{user?.day}. Nap</h1>
                        <div className='text-center p-2 text-2xl'>A mai napra készen vagy!</div>
                    </>
                    :
                    <div className='text-3xl font-semibold text-red-500 text-center p-5'>
                        <a href='/login'>Jelenleg nincs egy programod sem!</a>
                    </div>

                :
                <div className='text-3xl font-semibold text-red-500 text-center p-5'>
                    <a href='/login'>Először jelentkezz be!</a>
                </div>
            }
        </div>
    )
}

export default TrainingPage