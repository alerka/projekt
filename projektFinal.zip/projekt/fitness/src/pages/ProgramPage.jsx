import React, { useState, useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import NavBar from '../components/NavBar';
import power from '../imgs/powerlifter.jpg'
import clsx from 'clsx';

const ProgramPage = () => {
    const [searchParam, setSearchParams] = useSearchParams();
    const { user, programs } = useAuth();
    const [program, setProgram] = useState();
    const [error, setError] = useState();
    const navigator = useNavigate();
    useEffect(() => {
        if (programs) {
            for (let i = 0; i < programs.length; i++) {
                if (programs[i].id == searchParam.get("id")) {
                    //console.log(programs[i]);
                    setProgram(programs[i]);
                }
            }
        }
    }, [programs]);
    const handleClick = async () => {
        if (!user) {
            navigator("/login", { replace: true })
            return;
        }
        if (user.programId) {
            setError("Már van kiválasztva programod!");
            return;
        }
        const data = {
            programId: program.id
        }
        const response = await fetch("http://localhost:8000/user/setUserProgram", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("token")
            },
            body: JSON.stringify(data)
        });
        const valasz = await response.json();
        setError(valasz.message);
    }
    return (
        <>
            <NavBar />
            {program ?
                <div className='font-sans w-4/5 m-auto bg-gray-200 p-3 h-full grid grid-cols-2 max-md:grid-cols-1'>
                    <div className='flex justify-center'>
                        <div className='flex max-xl:w-9/12 xl:w-[30rem] max-md:w-full h-[42rem] border'>
                            <img className=' object-cover' src={program?.image} />
                        </div>
                    </div>
                    <div className='p-2'>
                        <h1 className='font-semibold text-3xl mb-6 max-md:text-center'>{program.title}</h1>
                        <div className='mb-16'>
                            <p className='text-red-600'>{error}</p>
                            <div className={clsx('p-3 bg-green-500 w-1/2 rounded border max-md:w-full border-emerald-500 hover:bg-emerald-400 text-center text-white', user?.programId ? 'cursor-not-allowed' : 'cursor-pointer')} onClick={handleClick}>
                                Kiválasztás
                            </div>
                        </div>
                        <div className='font-medium'>
                            {program.descriptionLong}
                        </div>
                        <div className='font-thin text-sm text-right pt-72'>*Figyelem egy programot csak egyszer
                            tudsz kiválasztani és később nem tudod megváltoztatni!</div>
                    </div>
                </div>
                :
                <h1 className='font-sans text-3xl text-red-500 p-3 text-center'>Nincs ilyen program!</h1>
            }
        </>
    )
}

export default ProgramPage