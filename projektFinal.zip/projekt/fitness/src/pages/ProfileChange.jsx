import React, { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import NavBar from '../components/NavBar';

const profileInfo = () => {
    const { user } = useAuth();
    const [error, setError] = useState();
    const [data, setData] = useState({});
    const handleChange = (e) => {
        setData({ ...data, [e.target.id]: e.target.value });
    }

    const changeData = async () => {
        if (Object.keys(data).length > 0) {
            if (data.name) {
                if (data?.name.length < 4) {
                    setError("A felhasználónév túl rövid!");
                    return;
                }
            }
            if (data.phone) {
                if (data?.phone.length != 11) {
                    setError("Helytelen telefonszám!");
                    return;
                }
            }
            if (data.email) {
                if (!data?.email.includes("@")) {
                    setError("Helytelen email!");
                    return;
                }
            }
            if (data.email == user.email && data.name == user.name && data.phone == user.phone) {
                setError("Adat nem változott!");
                return;
            }
            setError();
            const response = await fetch("http://localhost:8000/user/update", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer "+localStorage.getItem("token")
                },
                body: JSON.stringify(data)
            });
            location.href = 'http://localhost:5173/profileInfo'
        } else {
            setError("Nem változott adat!");
        }
    }

    return (
        <>
            <NavBar />
            <p className='bg-teal-600 mt-4 p-2 text-xl text-white font-semibold text-center'>Adatok változtatása</p>
            <div className='bg-gray-200 border border-gray-300 shadow-md m-2 rounded'>
                <p className='text-2xl text-center font-bold text-red-600'>{error}</p>
                <div className='p-2 rounded grid grid-cols-2 max-md:grid-cols-1'>
                    <div className='flex justify-center items-center '>
                        <p className='font-semibold text-right'>Felhasználónév: </p>
                    </div>
                    <input className='w-1/2 p-1 max-sm:w-full rounded border border-teal-500 justify-end' type='text' placeholder='új felhasználónév' id="name" defaultValue={user?.name} onChange={handleChange}></input>
                </div>
                <div className='p-2 rounded grid grid-cols-2 max-md:grid-cols-1'>
                    <div className='flex justify-center items-center '>
                        <p className='font-semibold text-right'>Email cím: </p>
                    </div>
                    <input className='w-1/2 p-1 max-sm:w-full rounded border border-teal-500 justify-end' type='text' placeholder='új email' id="email" defaultValue={user?.email} onChange={handleChange}></input>
                </div>
                <div className='p-2 rounded grid grid-cols-2 max-md:grid-cols-1'>
                    <div className='flex justify-center items-center    '>
                        <p className='font-semibold text-right'>Telefonszám: </p>
                    </div>
                    <input className='w-1/2 p-1 max-sm:w-full rounded border border-teal-500 justify-end' type='text' placeholder='új telefonszám' id="phone" defaultValue={user?.phone} onChange={handleChange}></input>
                </div>
                <div className='p-2 rounded grid grid-cols-2 max-md:grid-cols-1'>
                    <div></div>
                    <div className='max-sm:w-full cursor-pointer bg-green-500 border border-green-600 hover:bg-green-600 rounded text-white text-center w-1/3' onClick={changeData}>Mentés</div>
                </div>
            </div>
        </>
    )
}

export default profileInfo