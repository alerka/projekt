const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 8000;

app.use(express.json());
app.use(cors())

app.listen(PORT, () =>{
    console.log("Ezen a porton fut a backend: "+PORT)
})

app.use('/user', require('./routes/userRoutes'));
app.use('/api', require('./routes/exerciseRoutes'));