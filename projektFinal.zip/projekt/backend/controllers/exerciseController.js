const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

const getExercise = async (req, res) => {
    const { type, id, program } = req.query;
    if (type) {
        if (program == "bw") {
            const exercises = await prisma.exercise.findMany({
                where: {
                    type: type,
                    bodyWeight: true
                }
            });
            res.json(exercises);
            return;
        } else {
            if (type == "Rest") {
                const exercises = await prisma.exercise.findMany({
                    where: {
                        type: type,
                        bodyWeight: true
                    }
                });
                res.json(exercises);
                return;
            } else {
                const exercises = await prisma.exercise.findMany({
                    where: {
                        type: type,
                        bodyWeight: false

                    }
                });
                res.json(exercises);
                return;
            }
        }
    }
    if (id) {
        const exercises = await prisma.exercise.findFirst({
            where: {
                id: parseInt(id)
            }
        });
        res.json(exercises);
        return;
    }
    const exercises = await prisma.exercise.findMany();
    res.json(exercises)
    return;
}

const getPrograms = async (req, res) => {
    const programs = await prisma.programs.findMany();
    res.json(programs);
}

const getProgramsPlan = async (req, res) => {
    const { programId } = req.query;
    const programsP = await prisma.programsPlan.findUnique({
        where: {
            id: parseInt(programId)
        },
        select: {
            mday: true,
            tdday: true,
            wday: true,
            trday: true,
            fday: true,
            stday: true,
            snday: true
        }
    })
    res.json(programsP);
}

module.exports = {
    getPrograms,
    getExercise,
    getProgramsPlan
}