const { PrismaClient, Prisma } = require("@prisma/client");
const jwt = require("jsonwebtoken");
const arg2 = require('argon2');

const prisma = new PrismaClient();

const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '1d' })
}

const register = async (req, res) => {
    const { name, email, password, phone } = req.body;

    if (!name || !email || !password || !phone) {
        res.json({ message: "Hiányzó adatok!" });
        return;
    }

    const user = await prisma.users.findUnique({
        where: {
            email: email
        }
    })

    if (user) {
        res.json({ message: "Ez az email már foglalt!" });
        return;
    }

    const hashelt = await arg2.hash(password);
    const ujUser = await prisma.users.create({
        data: {
            email: email,
            name: name,
            phone: phone,
            password: hashelt,
            lastLogin: new Date(),
            day: 0
        }
    })

    const token = generateToken(ujUser.id);
    res.json({ token: token });
}

const login = async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        res.json({ message: "Hiányzó adatok!" });
        return;
    }

    const user = await prisma.users.findUnique({
        where: {
            email: email
        }
    })

    if (!user) {
        res.json({ message: "Nincs ilyen felhasználó!" });
        return;
    }

    if (!(await arg2.verify(user.password, password))) {
        res.json({ message: "Nem megfelelő jelszó!" })
        return;
    }

    const updated = await prisma.users.update({
        where: {
            id: user.id
        },
        data: {
            lastLogin: new Date()
        }
    })

    const token = generateToken(user.id);
    res.json({
        token: token
    });
}

const getDays = async (req, res) => {
    let user = req.user;
    let { day } = req.query;

    if (!day) {
        day = user.day;
        if (day <= 0) {
            day = 1;
        }
    }

    const napok = await prisma.days.findMany({
        where: {
            userId: user.id,
            day: parseInt(day)
        }
    })

    res.json(napok);
}

const setUserDay = async (req, res) => {
    let user = req.user;
    let { exerciseId, quanity, weight, series } = req.body;

    if (!user) {
        res.json({ error: "Helytelen felhasználó!" })
        return;
    }
    if (!exerciseId || !quanity || !series) {
        res.json({ error: "Helytelen adatok" })
        return;
    }
    const napok = await prisma.days.create({
        data: {
            userId: user.id,
            exerciseId: exerciseId,
            quanity: quanity,
            day: user.day,
            date: new Date(),
            weight: weight,
            series: Number(series),
        }
    })
    const an = await prisma.users.update({
        where: {
            id: user.id
        },
        data: {
            day: user.day + 1
        }
    })
    if(user.day+1 >= 90) {
        const reset = await prisma.users.update({
            where: {
                id: user.id
            },
            data: {
                programId: null,
                day: 0
            }
        })
        const delet = await prisma.days.deleteMany({
            where: {
                userId: user.id
            }
        })
    }
    res.json({ message: "Sikeresen felvitted az adatokat!" });

}

const setUserProgram = async (req, res) => {
    let user = req.user
    let { programId } = req.body;
    if (!user) {
        res.json({ error: "Helytelen felhasználó!" })
    }
    const update = await prisma.users.update({
        where: {
            id: user.id
        },
        data: {
            programId: Number(programId),
            day: 1
        }
    })
    res.json({ message: "Sikeresen kiválasztottad a programot!" })
}

const updateUser = async(req, res) => {
    let user = req.user;
    let { name, phone, email } = req.body;
    if(!name) {
        name = user.name;
    }
    if(!phone) {
        phone = user.phone
    }
    if(!email) {
        email = user.email;
    }
    const frissites = await prisma.users.update({
        where: {
            id: user.id
        },
        data: {
            name: name,
            phone: phone,
            email: email
        }
    })
    res.json({ message: "Adatok mentve!"});
}

const getUser = async (req, res) => {
    res.json(req.user);
}

module.exports = {
    login,
    register,
    getDays,
    setUserProgram,
    getUser,
    updateUser,
    setUserDay
}