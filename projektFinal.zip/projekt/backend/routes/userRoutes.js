const express = require('express');
const router = express.Router();

const { register, login, getUser, getDays, setUserProgram, setUserDay, updateUser } = require('../controllers/userController')
const { protect } = require('../middleware/authMiddlewear');

router.post('/register', register);
router.post('/login', login);
router.get('/getUser', protect, getUser);
router.get('/getDays', protect, getDays);
router.post('/setUserProgram', protect, setUserProgram);
router.post('/setDay', protect, setUserDay);
router.post('/update', protect, updateUser);

module.exports = router;