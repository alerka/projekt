const express = require('express');
const router = express.Router();

const { getExercise, getPrograms, getProgramsPlan } = require('../controllers/exerciseController');

router.get('/exercises',getExercise);
router.get('/programs',getPrograms);
router.get('/programPlan', getProgramsPlan)

module.exports = router;