-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2024. Ápr 04. 14:37
-- Kiszolgáló verziója: 10.4.28-MariaDB
-- PHP verzió: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `fitness`
--
CREATE DATABASE IF NOT EXISTS `fitness` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `fitness`;
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `days`
--

CREATE TABLE `days` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `exerciseId` int(11) NOT NULL,
  `quanity` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `date` datetime(3) NOT NULL,
  `weight` double NOT NULL,
  `series` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `days`
--

INSERT INTO `days` (`id`, `userId`, `exerciseId`, `quanity`, `day`, `date`, `weight`, `series`) VALUES
(44, 1, 29, 4, 1, '2024-03-31 19:38:46.183', 0, 3),
(45, 1, 31, 8, 1, '2024-03-31 19:38:46.183', 0, 4),
(46, 1, 28, 11, 2, '2024-03-31 19:38:46.183', 20, 2),
(47, 1, 13, 10, 2, '2024-03-31 19:38:46.183', 80, 4),
(48, 1, 11, 4, 3, '2024-04-02 18:35:42.562', 0, 1),
(49, 1, 24, 11, 4, '2024-04-03 06:55:28.478', 35, 3),
(50, 1, 23, 9, 4, '2024-04-03 06:55:28.478', 40, 4),
(51, 1, 31, 1, 5, '2024-04-03 08:13:33.415', 0, 1),
(52, 1, 29, 1, 5, '2024-04-04 08:13:33.405', 0, 1),
(53, 1, 13, 7, 6, '2024-04-04 09:24:42.187', 80, 3);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `exercise`
--

CREATE TABLE `exercise` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL,
  `bodyWeight` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `exercise`
--

INSERT INTO `exercise` (`id`, `name`, `type`, `bodyWeight`) VALUES
(6, 'Tolóckodás', 'Push', 1),
(7, 'Tricepsz lenyomás', 'Push', 0),
(8, 'Húzóckodás', 'Pull', 1),
(9, 'Felhúzás', 'Pull', 0),
(10, 'Húzóckodás', 'Pull', 1),
(11, 'Fekvőtámasz', 'Push', 1),
(12, 'Emelt fekvenyomás', 'Push', 1),
(13, 'Fekvenyomás', 'Push', 0),
(14, 'Lehúzás', 'Pull', 0),
(15, 'Felhúzás', 'Pull', 0),
(16, 'Kábeles evezés', 'Pull', 0),
(17, 'Evezés', 'Pull', 0),
(18, 'Tricepsz lenyomás', 'Push', 0),
(19, 'Vállból kinyomás kézi súlyzókkal', 'Push', 0),
(20, 'Ferdepados fekvenyomás', 'Push', 0),
(21, 'Guggolás', 'Leg', 1),
(22, 'Guggolás', 'Leg', 0),
(23, 'Combfeszítő', 'Leg', 0),
(24, 'Combhajlítás', 'Leg', 0),
(25, 'Meneteléses Guggolás', 'Leg', 0),
(26, 'Egy lábas guggolás', 'Leg', 1),
(27, 'Lábtoló', 'Leg', 0),
(28, 'Tolóckodás', 'Push', 1),
(29, 'Váll nyújtás', 'Rest', 1),
(30, 'Mell nyújtás', 'Rest', 1),
(31, 'Kar nyújtás', 'Rest', 1),
(32, 'Hát nyújtás', 'Rest', 1),
(33, 'Magasra ugrás', 'Leg', 1),
(34, 'Távolba ugrás', 'Leg', 1),
(35, 'Emelt lábas guggolás', 'Leg', 1),
(36, 'Láb Nyújtás', 'Rest', 1),
(37, 'Nyújtás', 'Rest', 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `programs`
--

CREATE TABLE `programs` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` varchar(191) NOT NULL,
  `descriptionLong` longtext NOT NULL,
  `image` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `programs`
--

INSERT INTO `programs` (`id`, `name`, `title`, `description`, `descriptionLong`, `image`) VALUES
(1, 'Calisthenic', 'Saját testsúlyos', 'Saját testsúlyos edzésforma, itt legtöbbször eszközök nélkül végezhető feladatok vannak.', 'A saját testsúlyos edzésforma segít funkcionális izmot építeni, hogy a saját testsúlyunkat tudjuk másképp használni. Lehet valaki erős és izmos, de nem feltétlen lesz olyan mint aki a saját testsúlyát tudja tökéletesen mozgatni. Ezzel az edzéssel mind erőt és mind izmot építünk, viszont hosszabb távon, viszont ez az erő/izom funckionális lesz, mivel a saját testsúlyunkat mozgatjuk vele, amire ki van találva.', './src/imgs/calisthenic.jpg'),
(2, 'Powerlifting', 'Erőemelő', 'Ez a program segít erőt építeni neked, hogy minnél több súlyt tudj mozgatni.', 'Ebben a programban erőt fogunk növelni, hogy sok súlyt tudjunk felemelni, kinyomni mind gugolásba, fekvenyomásba és felhúzásban. A program lényege, hogy nagy súlyokat emeljünk jó formával és olyan nehézséggel hogy 3-6 ismétlés menjen bukásig.', '/src/imgs/powerlifter.jpg'),
(5, 'Bodybuilding', 'Testépítő', 'Szeretnél nagy izmokat? Ez lesz a te programod, edzőterembe járás, alap edzéstervvel.', 'Izom építés megfelelő gyakorlatok végrahajtásával, kontrollált súlyok mozgatásával, progresszív túlterheléssel. Ajánlott, hogy az ismétlések 8-16 között legyenek bukásig. Minden szériában próbáljunk bukásig elmenni és szépen lassan kontrollálni a súlyt visszafele is.', './src/imgs/bodybuilding.jpg');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `programsplan`
--

CREATE TABLE `programsplan` (
  `id` int(11) NOT NULL,
  `programsId` int(11) NOT NULL,
  `mday` varchar(191) NOT NULL,
  `tdday` varchar(191) NOT NULL,
  `wday` varchar(191) NOT NULL,
  `trday` varchar(191) NOT NULL,
  `fday` varchar(191) NOT NULL,
  `stday` varchar(191) NOT NULL,
  `snday` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `programsplan`
--

INSERT INTO `programsplan` (`id`, `programsId`, `mday`, `tdday`, `wday`, `trday`, `fday`, `stday`, `snday`) VALUES
(1, 5, 'Push', 'Pull', 'Rest', 'Push', 'Pull', 'Leg', 'Rest'),
(2, 2, 'Pull', 'Push', 'Leg', 'Push', 'Rest', 'Pull', 'Rest'),
(3, 5, 'Push', 'Push', 'Push', 'Rest', 'Pull', 'Pull', 'Pull');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `phone` varchar(191) NOT NULL,
  `day` int(11) NOT NULL,
  `lastLogin` datetime(3) NOT NULL,
  `programId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `name`, `phone`, `day`, `lastLogin`, `programId`) VALUES
(1, 'asd@asd.hu', '$argon2id$v=19$m=65536,t=3,p=4$HKSLqxc0Eww9nrm09iZGWQ$m8JVjYdwJVseGyWq/779b9hhW15OZskR8h5F/F2yFbs', 'alex', '06123451278', 7, '2024-04-04 08:16:17.237', 2);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `days`
--
ALTER TABLE `days`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Days_userId_fkey` (`userId`),
  ADD KEY `Days_exerciseId_fkey` (`exerciseId`);

--
-- A tábla indexei `exercise`
--
ALTER TABLE `exercise`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `programsplan`
--
ALTER TABLE `programsplan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ProgramsPlan_programsId_fkey` (`programsId`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_key` (`email`),
  ADD KEY `users_programId_fkey` (`programId`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `days`
--
ALTER TABLE `days`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT a táblához `exercise`
--
ALTER TABLE `exercise`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT a táblához `programs`
--
ALTER TABLE `programs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT a táblához `programsplan`
--
ALTER TABLE `programsplan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `days`
--
ALTER TABLE `days`
  ADD CONSTRAINT `Days_exerciseId_fkey` FOREIGN KEY (`exerciseId`) REFERENCES `exercise` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `Days_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Megkötések a táblához `programsplan`
--
ALTER TABLE `programsplan`
  ADD CONSTRAINT `ProgramsPlan_programsId_fkey` FOREIGN KEY (`programsId`) REFERENCES `programs` (`id`) ON UPDATE CASCADE;

--
-- Megkötések a táblához `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_programId_fkey` FOREIGN KEY (`programId`) REFERENCES `programs` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
